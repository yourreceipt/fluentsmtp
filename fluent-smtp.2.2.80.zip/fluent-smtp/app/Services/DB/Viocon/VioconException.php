<?php namespace FluentMail\App\Services\DB\Viocon;


class VioconException extends \Exception
{

}
