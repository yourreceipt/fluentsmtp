Hi There,
Are you seeing this email? You are? Well awesome - that means you're all set to start sending emails from your site.
Thank you for using FluentSMTP 🎉

This Email sent at (server time): <?php echo date('Y-m-d H:i:s'); ?>